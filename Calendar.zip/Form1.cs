﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Management.Instrumentation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calendar
{
    public partial class Form1 : Form
    {

        // mysql DB 연결하기
        String connString = "Server=localhost;Database=db_calender;Uid=root;Pwd=12345678";

        // 전역변수로 달, 월
        int month, year, day;

        // 흠... 일정등록창으로 보내기 위한 정적변수 만들기
        public static int static_month, static_year, static_day;
        public static string eventDate;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            DateTime now = DateTime.Now;

            // 년, 월 변수에 현재 년도와 월 넣기
            month = now.Month;
            year = now.Year;
            day = now.Day;
            static_month = month;
            static_year = year;

            displayDays(year, month);

        }

        private void btn_eventAdd_Click(object sender, EventArgs e)
        {
            // 일정등록창(EventForm) 보이기
            EventForm eventform = new EventForm();

            eventform.Show();
        }

        /// 날짜 보여주는 함수
        public void displayDays(int nYear, int nMonth)
        {
            // DateTime.Now : 현재 현지 날짜와 시간이 값인 개체
            // DateTime now = DateTime.Now;
            // Console.WriteLine(now);
            // 2022-10-25 오후 6:33:17

            // 년, 월 변수에 현재 년도와 월 넣기
            // month = now.Month;
            // year = now.Year;

            month = nMonth;
            year = nYear;

            String monthname = DateTimeFormatInfo.CurrentInfo.GetMonthName(month);
            // Console.WriteLine(monthname); // 10월
            // 캘린더 상단 년도와 월 보여주는 레이블 LBDATE
            LBDATE.Text = year + "년 " + monthname;

            static_month = month;
            static_year = year;


            // 각 월의 1일 가져오기
            DateTime startofthemonth = new DateTime(year, month, 1);
            //Console.WriteLine(startofthemonth); //2022-10-01 오전 12:00:00

            // 각 월의 일(days) 수
            int days = DateTime.DaysInMonth(year, month);
            // Console.WriteLine(days); // 31

            // 각 월의 1일 요일구하기: dayoftheweek 함수 사용
            // startofthemonth을 정수(integer)로 바꾸기 
            // -> Convert.ToInt32() : 지정된 값을 32비트 부호 있는 정수로 변환
            int dayoftheweek = Convert.ToInt32(startofthemonth.DayOfWeek.ToString("d"));
            // Console.WriteLine(dayoftheweek); // 6


            // 각 월의 1일 위치 이전에 비워두는 날짜 생성하기~! 
            // UserControlBlank의 객체 생성해서 dayoftheweek만큼 daycontainer에 보여주기
            for (int i = 0; i < dayoftheweek; i++)
            {
                UserControlBlank ucblank = new UserControlBlank();
                // daycontainer에 컨트롤 ucblank을 추가한다?? 
                daycontainer.Controls.Add(ucblank);
            }

            // now lets create usercontrol for days
            // 이제 usercontroldays 객체(ucdays) 생성해서 각 월의 날짜를 넣어주자. 
            for (int i = 1; i <= days; i++)
            {
                UserControlDays ucdays = new UserControlDays();
                ucdays.days(i);
                ucdays.DisplayEvent(i);
                // 클릭이벤트
                ucdays.LabelDayClick += new EventHandler(UserControl_LabelClick);
                daycontainer.Controls.Add(ucdays);
            }
        }

        private void btnprev_Click(object sender, EventArgs e)
        {
            // 이전 달 보여줘야 하니까 이전의 달력 지우기
            daycontainer.Controls.Clear();


            // prev 버튼 누르면 현재 월에 -1씩 추가 (이전 달로 이동해야 하니까~!)

            month--;
            if (month == 0)
            {
                month = 12;
                year--;
            }

            static_day = 1;

            // 타입확인
            //Console.WriteLine(year.GetType().Name);
            //Console.Write(year);
            displayDays(year, month);
        }

        private void btnnext_Click(object sender, EventArgs e)
        {
            // 다음 달 보여줘야 하니까 이전의 달력 지우기
            daycontainer.Controls.Clear();


            // next 버튼 누르면 현재 월에 +1씩 추가 (다음달로 이동해야 하니까~!)
            month++;

            if (month == 13)
            {
                month = 1;
                year++;
            }
            static_day = 1;

            // 타입확인
            //Console.WriteLine(year.GetType().Name);
            //Console.Write(year);
            displayDays(year, month);
        }


        public void UserControl_LabelClick(object sender, EventArgs e)
        {
            // 날짜 클릭시 보여주는 이벤트 날짜
            string eventDate = static_year + "년 " + static_month + "월 " + static_day + "일";

            ShowEventControl showevent = new ShowEventControl();
            List<ShowEventControl> list = new List<ShowEventControl>();


            showevent.ShowEvent();
            ShowEventContainer.Controls.Add(showevent);
         }

    }
}
