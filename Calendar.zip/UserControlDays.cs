﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calendar
{
    public partial class UserControlDays : UserControl
    {
        // mysql DB 연결하기
        String connString = "Server=localhost;Database=db_calender;Uid=root;Pwd=12345678";


        public UserControlDays()
        {
            InitializeComponent();
        }
        public void days(int numday)
        {
            lbdays.Text = numday + "";
        }

        // 라벨 이벤트 핸들러
        public event EventHandler LabelDayClick;

        public void lbdays_Click(object sender, EventArgs e)
        {
            // timer1.Start();
            Form1.static_day = Int32.Parse(lbdays.Text);

            //Form1 form = new Form1();
            //form.displayEvents();
            //form.Hide();
            // 일단 이렇게....
            //Application.OpenForms[0].Close();
            //form.Show();
            //Console.Write(Application.OpenForms);
            //Console.Write(Form1.static_day + "\n");
            //bubble the event up to the parent


            if (this.LabelDayClick != null)

                this.LabelDayClick(this, e);
        }


        public void DisplayEvent(int day)
        {
            //Form1.static_day = day;
            MySqlConnection conn = new MySqlConnection(connString);
            conn.Open();

            string sel_sql = "select event from event_table where date = ?";
            
            MySqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = sel_sql;
            cmd.Parameters.AddWithValue("date", Form1.static_year + "-" + Form1.static_month + "-" + day + "-");
            MySqlDataReader reader = cmd.ExecuteReader();

            if (reader.Read())
            {
                lbEventTitle.Text = reader["event"].ToString();
            }
            //cmd.ExecuteNonQuery();

            reader.Dispose();

            cmd.Dispose();
            conn.Close();

        }

    }
}
