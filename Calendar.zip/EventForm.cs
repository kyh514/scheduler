﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
// Mysql namespace를 사용하기 위한 선언 
using MySql.Data.MySqlClient;
using MySqlX.XDevAPI.Relational;

namespace Calendar
{
    public partial class EventForm : Form
    {
        // mysql DB 연결하기
        String connString = "Server=localhost;Database=db_calender;Uid=root;Pwd=12345678";

        public EventForm()
        {
            InitializeComponent();
        }

        private void EventForms_Load(object sender, EventArgs e)
        {
            txDate.Text = Form1.static_year + "-" + Form1.static_month + "-" + Form1.static_day;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string date = txDate.Text;
            string date_event = txEvent.Text;

            MySqlConnection conn = new MySqlConnection(connString);
            conn.Open();

            // 일정 db에 저장
            string insert_sql = "insert into event_table(date, event, event_content) values(?,?,?)";

            //MySqlCommand cmd = new MySqlCommand(insert_sql, conn);
            MySqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = insert_sql;
            cmd.Parameters.AddWithValue("date", txDate.Text);
            cmd.Parameters.AddWithValue("event", txEvent.Text);
            cmd.Parameters.AddWithValue("content", txContent.Text);
             
            cmd.ExecuteNonQuery();

            MessageBox.Show("일정이 등록되었습니다.");
            cmd.Dispose();
            conn.Close();
            this.Close();
     
        }
    }
}
