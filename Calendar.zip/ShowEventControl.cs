﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calendar
{
    public partial class ShowEventControl : UserControl
    {

        // mysql DB 연결하기
        String connString = "Server=localhost;Database=db_calender;Uid=root;Pwd=12345678";

        public ShowEventControl()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void ShowEventControl_Load(object sender, EventArgs e)
        {
            
        }

        public void ShowEvent()
        {
            //Form1.static_day = day;
            MySqlConnection conn = new MySqlConnection(connString);
            conn.Open();

            string sel_sql = "select * from event_table where date = ?";

            MySqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = sel_sql; 
            cmd.Parameters.AddWithValue("date", Form1.static_year + "-" + Form1.static_month + "-" + Form1.static_day + "-");
            MySqlDataReader reader = cmd.ExecuteReader();

            // db에 등록된 데이터 모두 읽으려면 while문 사용
            while (reader.Read()==true)
            {
                lbEvent.Text = reader["event"].ToString();
                lbContent.Text = reader["event_content"].ToString();
                lbDate.Text = reader["date"].ToString();


                Console.WriteLine(lbEvent.Text);
                Console.WriteLine(lbContent.Text);
                Console.WriteLine(lbDate.Text);
            }
            
            //cmd.ExecuteNonQuery();

            reader.Dispose();

            cmd.Dispose();
            conn.Close();
        }
    }
}
